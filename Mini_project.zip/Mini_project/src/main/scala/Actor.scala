class Actor(name: String, surname: String,var movies: List[Movie] = Nil) extends Personnalités with Comparable {

  override def nom = name

  override def prenom = surname

  var films = movies

  var moyenne: Double = 0.0


  override def < (actor: Any): Boolean = {
    if (!actor.isInstanceOf[Actor]) sys.error("incomparable : " + actor + "(" + actor.getClass + ")and Point")
    val p = actor.asInstanceOf[Actor]
    p.moyenne > this.moyenne
  }

  override def equals(actor: Any): Boolean = {
    actor.isInstanceOf[Actor] && {
      val p = actor.asInstanceOf[Actor]
      p.moyenne == this.moyenne
    }
  }

  override def addMovie(movie: Movie): Unit = {
    films = movie :: films
    recalculerMoyenne()
  }

  private def recalculerMoyenne(): Unit = {
    val ratings = films.map(_.note)
    moyenne = if (ratings.isEmpty) 0.0 else ratings.sum / ratings.length
  }

  def affiche(): Unit = {
    println(nom,moyenne)
  }


  override def toString: String = s"Acteur: $nom $prenom"




}