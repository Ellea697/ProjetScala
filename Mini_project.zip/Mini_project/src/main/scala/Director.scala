import scala.collection.mutable
import scala.collection.mutable._

class Director(name: String, surname: String,movies: List[Movie] = Nil) extends Personnalités with Comparable {

  override def nom = name
  override def prenom = surname
  var films = movies
  var moyenne: Double = 0.0



  override def < (director: Any): Boolean = {
    if (!director.isInstanceOf[Director]) sys.error("incomparable : " + director + "(" + director.getClass + ")and Point")
    val p = director.asInstanceOf[Director]
    p.moyenne > this.moyenne
  }

  override def equals(director: Any): Boolean = {
  director.isInstanceOf[Director] && {
    val p = director.asInstanceOf[Director]
    p.moyenne == this.moyenne
  }
  }

  override def addMovie(movie: Movie): Unit = {
    films = movie :: films
    recalculerMoyenne()
  }

  private def recalculerMoyenne(): Unit = {
    val ratings = films.map(_.note)
    moyenne = if (ratings.isEmpty) 0.0 else ratings.sum / ratings.length
  }

  override def toString: String = s"Directeur: $nom $prenom "




}