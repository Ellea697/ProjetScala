class Cinematheque {
  var films: List[Movie] = Nil

  def addMovie(movie: Movie): Unit = {
    films = movie :: films

  }

  def affiche():Unit={

    films.toList

  }

}
