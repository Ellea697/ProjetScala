import java.rmi.registry.Registry
import scala.io.{BufferedSource, Source, StdIn}
import scala.util.matching.Regex
import scala.collection.mutable
import scala.collection.mutable._


object ScalaWorld {

  def main(arg: Array[String]): Unit = {

    println("Veuillez entrer le chemin complet du fichier CSV:")
    /* val filePath = StdIn.readLine()*/
    val buf = Source.fromFile("C:\\Users\\ananf\\OneDrive\\Documents\\Aivancity\\Scala\\moviesSemiCol.csv")
    val cinematheque  = new Cinematheque
    val registry = new Register

    for (line <- buf.getLines().drop(1)) {

      val col = line.split(";").map(_.trim)

      val title = col(0)
      val years = col(1)
      val yearRegex = new Regex("\\d{4}")
      val matchResult = yearRegex.findFirstIn(years)
      val year = matchResult.getOrElse("").toInt

      val directors = col(5)
      val cleaneddirector = directors.stripPrefix("[").stripSuffix("]")
      val cleaneddirector2 = cleaneddirector.stripPrefix("\"[").stripSuffix("]\"")
      val cleaneddirector3 = cleaneddirector2.replace("\"\"", "'")
      val cleaneddirector4 = cleaneddirector3.replace("'", "")
      val listeDeNoms = cleaneddirector4.split(", ").toList


      /*Traitement Directeur*/


      def createOrUpdateDirector(nom: String, prenom: String): Director = {
        registry.getDirector(nom, prenom) match {
          case Some(existingDirector) => existingDirector
          case None =>
            val nouveauDirecteur = new Director(nom, prenom)
            registry.addDirector(nouveauDirecteur)
            nouveauDirecteur
        }
      }


      val directorsname = listeDeNoms.map { nomComplet =>
        val partiesdirector = nomComplet.split(" ")

        if (partiesdirector.length == 1) {
          val nom = partiesdirector(0)
          val prenom = ""
          createOrUpdateDirector(nom, prenom)

        } else if (partiesdirector.length == 2) {
          val nom = partiesdirector(0)
          val prenom = partiesdirector(1)
          createOrUpdateDirector(nom, prenom)

        } else {
          val nom = partiesdirector.head
          val prenom = partiesdirector.tail.mkString(" ")
          createOrUpdateDirector(nom, prenom)

        }
      }
      /*Fin traitement Director*/


      /*Traitement Actor*/

      val actors = col(6)
      val cleanedactor = actors.stripPrefix("[").stripSuffix("]")
      val cleanedactor2 = cleanedactor.stripPrefix("\"[").stripSuffix("]\"")
      val cleanedactor3 = cleanedactor2.replace("\"\"", "'")
      val cleanedactor4 = cleanedactor3.replace("'", "")
      val listeDeNomsactor = cleanedactor4.split(", ").toList


      def createOrUpdateActor(nom: String, prenom: String): Actor = {
        registry.getActor(nom, prenom) match {
          case Some(existingActor) => existingActor
          case None =>
            val nouvelActeur = new Actor(nom, prenom)
            registry.addActor(nouvelActeur)
            nouvelActeur
        }
      }

      val actorsname = listeDeNomsactor.map { nomComplet =>
        val partiesactor = nomComplet.split(" ")

        if (partiesactor.length == 1) {
          val nom = partiesactor(0)
          val prenom = ""
          createOrUpdateActor(nom, prenom)

        } else if (partiesactor.length == 2) {
          val nom = partiesactor(0)
          val prenom = partiesactor(1)
          createOrUpdateActor(nom, prenom)

        } else {
          val nom = partiesactor.head
          val prenom = partiesactor.tail.mkString(" ")
          createOrUpdateActor(nom, prenom)

        }
      }
      /* Fin Traitement Actor*/

      val ratings = col(7)
      val cleanedratings = ratings.replace(",", ".")
      val rating = cleanedratings.toFloat

      val movie = new Movie(title,year,directorsname,actorsname, rating)

      directorsname.foreach { director =>
        director.addMovie(movie)
      }

      actorsname.foreach { actor =>
        actor.addMovie(movie)
      }

      cinematheque.addMovie(movie)
    }
    buf.close()
    cinematheque.affiche()


    val directeursTries = registry.directeurs.toList.sortWith((director1, director2) => director1 < director2)
    val premiers20Directeurs = directeursTries.take(20)
    premiers20Directeurs.foreach { directeur =>

      println(s"${directeur.nom} ${directeur.prenom}: ${directeur.moyenne}")

    }

    val filmsRecents = cinematheque.films.filter(_.annee >= 2015)
    println(filmsRecents)

    val highRatedFilms = cinematheque.films.filter(_.note > 8.0)
    println(highRatedFilms)

  }

}
