import scala.collection.mutable

class Register {

  val acteurs: mutable.Set[Actor] = mutable.HashSet.empty[Actor]
  val directeurs: mutable.Set[Director] = mutable.HashSet.empty[Director]

  def addActor(actor: Actor): Unit = {
    acteurs += actor
  }

  def getActor(nom: String, prenom: String): Option[Actor] = {
    acteurs.find(a => a.nom == nom && a.prenom == prenom)
  }

  def addDirector(director: Director): Unit = {
    directeurs += director
  }

  def getDirector(nom: String, prenom: String): Option[Director] = {
    directeurs.find(d => d.nom == nom && d.prenom == prenom)
  }

  def afficheact(): Unit = {
    println(acteurs)
  }

  def affichedirect(): Unit = {
    directeurs.toList
  }
}
