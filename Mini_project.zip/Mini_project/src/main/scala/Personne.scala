import scala.collection.mutable._

trait Personne {

  def nom: String
  def prenom: String

}