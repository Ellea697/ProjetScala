import scala.collection.mutable._

class Movie(title: String, year: Int, val director: List[Director],val stars: List[Actor],rating : Float) extends Comparable {
  private def titre = title

  def annee = year

  private def directeur = director

  private def acteur = stars

   def note = rating

  override def equals(movie: Any): Boolean = {
    movie.isInstanceOf[Movie] && {
      val p = movie.asInstanceOf[Movie]
      p.note == this.note
    }
  }

  override def <(movie: Any): Boolean = {
    if (!movie.isInstanceOf[Movie]) sys.error("incomparable : " + movie + "(" + movie.getClass + ")and Point")
    val p = movie.asInstanceOf[Movie]
    p.note > this.note
  }

  override def toString: String = s"Titre: $titre, Année : $annee, Acteur: $acteur, Directeur: $directeur,note : $note"

}
