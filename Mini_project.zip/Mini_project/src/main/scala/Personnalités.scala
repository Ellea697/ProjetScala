import scala.collection.mutable._

trait Personnalités {

  def nom: String
  def prenom: String
  var films: List[Movie]


  def addMovie(movie: Movie): Unit = {
    films.appended(movie)
  }

}


